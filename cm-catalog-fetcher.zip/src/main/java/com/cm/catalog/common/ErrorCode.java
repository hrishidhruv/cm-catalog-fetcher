package com.cm.catalog.common;

/**
 * Interface for getting the ErrorCode for exceptions
 * @author rdhruv
 *
 */
public interface ErrorCode {
	public int getErrorCode();
}
